function cambiarImagen(img) {

    let imagenCambio = img;
    document.getElementById("imagen").src=imagenCambio;

}
function alert(img){
    console.log(img);
}
/*** */
